import React, { Component } from 'react'
//import {Card} from 'react-bootstrap'


 class prodcat extends Component {
    
    state={
        services:[]
    }

    componentDidMount(){

        fetch('https://cors-anywhere.herokuapp.com/http://117.242.221.193:4000/brand/getcategories')
        .then(response => response.json()
        
        )
        .then((jsonData) => {
          this.setState({ services:jsonData})
          console.log(this.state.services)

        })
        .catch((error) => {
          // handle your errors here
          console.error(error)
        })
    }

    render() {
        return (
            <section className="services">
            <div className="services-center">

               

            </div>
            </section>
        )
    }
}
export default prodcat