import React from 'react'
import './css/login.css'
import logo from './images/logos.jpg'


function login() {
    return (
        <div className="bd">
            <div className="row">
        <div className="col-md-3" />
        <div className="col-md-6">
          <div className="card">
            <img src={logo} alt="alternat"/>
            <div className="row inner-option">
              <div className="col-md-3" />
              <div className="col-md-6">
                <h2>LOG-IN</h2>
              </div>
              <div className="col-md-3">
              </div>
            </div>
            <div className="row">
              <div className="col-md-12">
                <form>
                  <div className="form-group">
                    <input type="email" className="form-control" id="exampleInputEmail1" placeholder="Email" required />
                  </div>
                  <div className="form-group">
                    <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password" required />
                  </div>
                  <button type="submit" className="btn btn-primary">Submit</button>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3" />
      </div>
        </div>
    )
}

export default login
