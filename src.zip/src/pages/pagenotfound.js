import React from 'react'

function pagenotfound() {
    return (
        <div>
            404 PageNotFound
        </div>
    )
}

export default pagenotfound
