import React, { Component } from 'react'
import './css/login.css'
import logo from './images/logos.jpg'
//import Forming from '../components/forming'
//import Reg1 from './reg1'
//import Reg2 from './reg2'
class register extends Component {
  constructor()
  {
    super()
    this.handleChange=this.handleChange.bind(this);    
    this.validate=this.validate.bind(this);
    this.state={
      data:null,
      one:'   <div className="form-group">    <input type="text"     className="form-control"     name="org"     onChange={this.handleChange}  placeholder="Your Organisation Name" required />  </div> <div className="form-group">    <input type="text"     className="form-control"      onChange={this.handleChange}       value={this.state.crpid}       name="crpid"        placeholder="cid" required />  </div>',
      two:'  <div className="form-group">  <input type="text" className="form-control" onChange={this.handleChange} value={this.state.address} placeholder="Organisation Address" required /> </div>  <div className="form-group">  <input type="email" className="form-control" onChange={this.handleChange} value={this.state.email} placeholder="Organisation E-mail" " required /></div>',
      three:' <div className="form-group"><input type="password" className="form-control" id="pswrd" placeholder="Account Password"  title="Must contain at least one  number and one uppercase and lowercase letter, and at least 8 or more characters" required /></div>  <div className="form-group">  <input type="password" className="form-control" id="cpswrd" placeholder="Confirm Password" required /></div><div className="form-group"><b><p className="form-control">UPLOAD BRAND LOGO (PNG) </p></b></div><center><input type="file" id="myFile" name="filename" /></center>',
      disp:null,
      org: null,
        crpid: null,
        address:null,
        email:null,
        password:null,
        conpassword:null
        }
  }  

  validate(e)
  {
    e.preventDefault();
    console.log(this.state.org)
    console.log(this.state.crpid)
    const reg1=JSON.stringify(this.state)
    console.log(reg1)
  }

handleChange(e){
console.log("ad")
  this.setState({
  [e.target.name]: e.target.value
  
})

console.log(this.state)
}

 componentDidMount(){

  fetch('https://cors-anywhere.herokuapp.com/http://117.242.221.193:4000/brand/getcategories')
  .then(response => response.json())
  .then((jsonData) => {
    this.setState({ data:jsonData.categoryName})
    console.log(this.state.data)
  })
  .catch((error) => {
    // handle your errors here
    console.error(error)
  })


  this.eee="NEXT  →";
  console.log(this.state.one)
  this.setState({ disp:this.state.one})
  console.log(this.state.disp)
document.getElementById("formdisp").innerHTML+=this.state.disp  
} 

check(){
if(this.state.password!=="" && this.state.conpassword!==""){
  console.log(this.state)
}
  else if(this.state.email!==""&& this.state.address!==""){
    this.setState({ disp:this.state.three})
    this.eee="Submit"
  }
  else if(this.state.org!=="" && this.state.crpid!==""){
    this.setState({ disp:this.state.two})
  }
}


  

  render(){
    return (
        <div className="bd">
            <div className="row">
        <div className="col-md-3" />
        <div className="col-md-6">
          <div className="card">
            <img src={logo} alt="hello" />
            <div className="row inner-option">
              <div className="col-md-3" />
              <div className="col-md-6">
                <h2>SIGN-UP</h2>
              </div>
              <div className="col-md-3">
              </div>
            </div>
            <div className="row">
              <div className="col-md-12">
              <form id="formdisp"> 
                  
                
                  <button  className="btn btn-primary" onClick={this.check} > {this.eee}</button>
              </form>               
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3" />
      </div>
        </div>
    )
}
}
export default register
